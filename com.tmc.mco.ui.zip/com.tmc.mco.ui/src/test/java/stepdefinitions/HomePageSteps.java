//package parallel;
package stepdefinitions;

import java.util.List;
import java.util.Map;

import org.testng.Assert;

import com.factory.DriverFactory;
import com.pageobject.HomePage;
import com.pageobject.LoginPage;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class HomePageSteps {
	private LoginPage loginPage = new LoginPage(DriverFactory.getDriver());
	private HomePage homePage;
	private String homePageHeader;

	@Given("user has already logged in to the MCO application")
	public void user_has_already_logged_in_to_the_mco_application(DataTable credetialTable) {
		List<Map<String, String>> credList = credetialTable.asMaps();
		String username = credList.get(0).get("username");
		String password = credList.get(0).get("password");
		
		DriverFactory.getDriver().get("https://m-c-o.com/login");
		homePage = loginPage.doLogin(username, password);

	}

	@When("user checks the Home page header")
	public void user_checks_the_home_page_header() {
		homePageHeader=homePage.getHomePageHeader();
	}

	@Then("page header sould be {string}")
	public void page_header_sould_be(String expectedhomePageHeader) {
		Assert.assertTrue(homePageHeader.equals(expectedhomePageHeader));		
	}

	@Given("user is on Home page")
	public void user_is_on_home_page() {
		Assert.assertTrue(homePage.isLogOutPresent());
	}

	@Then("region is {string}")
	public void region_is(String expectedRegion) {
		Assert.assertTrue(homePage.getRegionText().trim().equals(expectedRegion));
	}

	@Then("user gets the Home page section")
	public void user_gets_the_home_page_section(DataTable homePageSectionTable) {
		
		List<String>expectedHPSectionList=homePageSectionTable.asList();	
		System.out.println("Expected Home Page section List: "+expectedHPSectionList);
		
		List<String> actualHPSectionList= homePage.getHomePageSectionList();
		System.out.println("Actual Home Page section List: "+actualHPSectionList);
		
		Assert.assertTrue(expectedHPSectionList.containsAll(actualHPSectionList));
	}

	@Then("Home page section count is {int}")
	public void home_page_section_count_is(Integer expectedSecCount) {
		Assert.assertTrue(homePage.getHomePageSecCount()== expectedSecCount);
	}

}
