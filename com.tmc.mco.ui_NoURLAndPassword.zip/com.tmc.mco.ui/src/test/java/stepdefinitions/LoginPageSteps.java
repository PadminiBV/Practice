//package parallel;

package stepdefinitions;

import org.junit.Assert;

import com.factory.DriverFactory;
import com.pageobject.HomePage;
import com.pageobject.LoginPage;

import io.cucumber.java.en.*;

public class LoginPageSteps {
	private static String title;
	private LoginPage loginPage= new LoginPage(DriverFactory.getDriver());
	private HomePage homePage= new HomePage(DriverFactory.getDriver());
	
	@Given("user is on MCO Login page")
	public void user_is_on_mco_login_page() {
	    DriverFactory.getDriver().get("");
	}

	@When("user gets the title of the page")
	public void user_gets_the_title_of_the_page() {
	    title=loginPage.getPageTitle();
	    System.out.println("Page tiltle is : "+title);
	}

	@Then("page title should be {string}")
	public void page_title_should_be(String expectedPageTitle) {
	   Assert.assertTrue(title.equals(expectedPageTitle)); 
	}

	@When("user enters the username {string}")
	public void user_enters_the_username(String username) {
	   loginPage.enterUsername(username);
	}

	@When("user enters the password {string}")
	public void user_enters_the_password(String password) {
	   loginPage.enterPassword(password);
	}

	@When("user clicks on login button")
	public void user_clicks_on_login_button() {
	    loginPage.clickLogin();
	}

	@Then("user lands on the home page")
	public void user_lands_on_the_home_page() {
		String homePageText=homePage.getHomePageHeader();
		Assert.assertTrue(homePageText.equals("HOME"));
	   
	}

}
