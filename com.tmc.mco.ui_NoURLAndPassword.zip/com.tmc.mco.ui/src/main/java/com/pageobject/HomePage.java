package com.pageobject;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomePage {
	
	private WebDriver driver;
	private LoginPage loginPage= new LoginPage(driver);
	private HomePage homePage;
	
	private By homePageTextXpath=By.xpath("//span[text()='Home']");
	private By homePageSelectionXpath=By.xpath("//div[@fxlayout='row wrap']//h3");
	private By logoutXpath =By.xpath("//mat-icon[contains(text(),'exit')]");
	private By regionLocatorCss=By.cssSelector("div.sidebar-bottom span div span");
	private By hopePageConditionXpath=By.xpath("//h3[@class='help-inline ng-star-inserted']");
	
	
	public HomePage(WebDriver driver) {
		this.driver=driver;
	}
	
	public String getHomePageHeader() {
		
		WebDriverWait wait =new WebDriverWait(driver, 20);
		WebElement homePageTextEle=wait.until(ExpectedConditions.presenceOfElementLocated(homePageTextXpath));
		return homePageTextEle.getAttribute("innerText");
	}
	
	public boolean isLogOutPresent() {
		boolean blnResult=false;
		WebDriverWait wait =new WebDriverWait(driver, 20);
		WebElement logoutXpathEle=wait.until(ExpectedConditions.presenceOfElementLocated(logoutXpath));
		if(logoutXpathEle.isDisplayed())
			blnResult=true;		
		return blnResult;
	}
	
	public String getRegionText() {
		return driver.findElement(regionLocatorCss).getText();
	}

	
	public int getHomePageSecCount() {
		return driver.findElements(homePageSelectionXpath).size();
	}
	
	public List<String> getHomePageSectionList(){
		WebDriverWait wait =new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.presenceOfElementLocated(hopePageConditionXpath));
		
		List<String> homePageSecList= new ArrayList<>();
		List<WebElement> homePageSecElements= driver.findElements(homePageSelectionXpath);
		
		for(WebElement e:homePageSecElements) {
			String eleText= e.getAttribute("innerText");
			System.out.println(eleText);
			homePageSecList.add(eleText);
		}
		
		
		return homePageSecList;
	}
}
