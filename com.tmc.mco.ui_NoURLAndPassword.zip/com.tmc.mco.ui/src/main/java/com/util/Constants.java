package com.util;

public class Constants {

}
